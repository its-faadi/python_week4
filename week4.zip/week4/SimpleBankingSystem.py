class BankAccount:
    def __init__(self, account_holder, account_number, initial_balance=0.0):
        # Initialize the account with holder's name, account number, and initial balance
        self.__account_holder = account_holder
        self.__account_number = account_number
        self.__balance = initial_balance

    def deposit(self, amount):
        # Deposit money into the account, ensuring the amount is positive
        if amount > 0:
            self.__balance += amount
            return True
        return False

    def withdraw(self, amount):
        # Withdraw money from the account if sufficient funds are available
        if amount > 0 and amount <= self.__balance:
            self.__balance -= amount
            return True
        return False

    def get_balance(self):
        # Return the current balance of the account
        return self.__balance

    def display_account_info(self):
        # Display account details
        return {
            "Account Holder": self.__account_holder,
            "Account Number": self.__account_number,
            "Balance": self.__balance
        }


def main():
    # Dictionary to store accounts with account number as key
    accounts = {}
    
    while True:
        try:
            # Display the main menu
            print("\nWelcome to the Simple Banking System")
            print("1. Create a new bank account")
            print("2. Deposit money")
            print("3. Withdraw money")
            print("4. View account balance")
            print("5. Display account details")
            print("6. Exit")

            # Get the user's choice
            choice = input("Enter your choice: ")

            if choice == '1':
                # Create a new bank account
                account_holder = input("Enter account holder's name: ")
                account_number = input("Enter account number: ")
                initial_balance = float(input("Enter initial balance: "))
                accounts[account_number] = BankAccount(account_holder, account_number, initial_balance)
                print("Account created successfully!")
            
            elif choice == '2':
                # Deposit money into an account
                account_number = input("Enter account number: ")
                amount = float(input("Enter amount to deposit: "))
                if account_number in accounts:
                    if accounts[account_number].deposit(amount):
                        print("Deposit successful!")
                    else:
                        print("Deposit failed! Invalid amount.")
                else:
                    print("Account not found!")

            elif choice == '3':
                # Withdraw money from an account
                account_number = input("Enter account number: ")
                amount = float(input("Enter amount to withdraw: "))
                if account_number in accounts:
                    if accounts[account_number].withdraw(amount):
                        print("Withdrawal successful!")
                    else:
                        print("Withdrawal failed! Insufficient balance or invalid amount.")
                else:
                    print("Account not found!")

            elif choice == '4':
                # View the balance of an account
                account_number = input("Enter account number: ")
                if account_number in accounts:
                    print(f"Current Balance: {accounts[account_number].get_balance()}")
                else:
                    print("Account not found!")

            elif choice == '5':
                # Display the details of an account
                account_number = input("Enter account number: ")
                if account_number in accounts:
                    account_info = accounts[account_number].display_account_info()
                    for key, value in account_info.items():
                        print(f"{key}: {value}")
                else:
                    print("Account not found!")

            elif choice == '6':
                # Exit the program
                print("Exiting the banking system. Goodbye!")
                break

            else:
                # Handle invalid menu choices
                print("Invalid choice. Please try again.")
        except ValueError:
            # Handle invalid numeric inputs
            print("Invalid input! Please enter numeric values for balance and amounts.")
        except Exception as e:
            # Handle any other unexpected errors
            print(f"An error occurred: {e}")

if __name__ == "__main__":
    main()
